import numpy as np
import pandas as pd
from scipy.stats import truncnorm, beta
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix, ConfusionMatrixDisplay
)
import matplotlib.pyplot as plt

def truncated_normal(mean, sd, low, upp, size):
    from scipy.stats import truncnorm
    return truncnorm((low - mean) / sd, (upp - mean) / sd, loc=mean, scale=sd).rvs(size)

coefficients = {
    'intercept': -3.0,
    'env_rat': 0.8,
    'emo_rat': 0.7,
    'socio_rat': 1.0,
    'infra_rat': 0.9,
    'tele_prop': 1.2,
    'local_prop': 0.6
}

def generate_forced_balanced_dataset(N):
    env_rat = truncated_normal(3.5, 0.7, 1, 5, N)
    emo_rat = truncated_normal(3.5, 0.7, 1, 5, N)
    socio_rat = truncated_normal(3.0, 0.8, 1, 5, N)
    infra_rat = truncated_normal(3.0, 0.8, 1, 5, N)
    tele_prop = beta(a=3, b=3).rvs(N)
    local_prop = beta(a=3, b=3).rvs(N)

    linear_comb = (
        coefficients['intercept'] +
        coefficients['env_rat'] * env_rat +
        coefficients['emo_rat'] * emo_rat +
        coefficients['socio_rat'] * socio_rat +
        coefficients['infra_rat'] * infra_rat +
        coefficients['tele_prop'] * tele_prop +
        coefficients['local_prop'] * local_prop
    )
    prob_attr = 1 / (1 + np.exp(-linear_comb))
    threshold = np.median(prob_attr)
    attr_label = (prob_attr >= threshold).astype(int)

    return pd.DataFrame({
        'Env_Rat': env_rat.round(2),
        'Emo_Rat': emo_rat.round(2),
        'Socio_Rat': socio_rat.round(2),
        'Infra_Rat': infra_rat.round(2),
        'Tele_prop': tele_prop.round(2),
        'Local_prop': local_prop.round(2),
        'Prob_Attr': prob_attr.round(2),
        'Attr_label': attr_label
    })

df = generate_forced_balanced_dataset(500)
X = df[['Env_Rat', 'Emo_Rat', 'Socio_Rat', 'Infra_Rat', 'Tele_prop', 'Local_prop']]
y = df['Attr_label']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, stratify=y, random_state=42)

model = LogisticRegression()
model.fit(X_train, y_train)
y_pred_prob = model.predict_proba(X_test)[:, 1]
y_pred = (y_pred_prob >= 0.5).astype(int)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall:", recall_score(y_test, y_pred))
print("F1 Score:", f1_score(y_test, y_pred))
print("ROC AUC:", roc_auc_score(y_test, y_pred_prob))

fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
plt.figure()
plt.plot(fpr, tpr, label=f"ROC Curve (AUC = {roc_auc_score(y_test, y_pred_prob):.2f})")
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - Logistic Regression")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Not Attractive", "Attractive"])
disp.plot(cmap='Blues', values_format='d')
plt.title("Confusion Matrix - Logistic Regression")
plt.tight_layout()
plt.show()