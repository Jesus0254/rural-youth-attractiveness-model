# Predictive Model of Rural Attractiveness for Urban Youth

This repository contains the source code, synthetic dataset, and visualizations for a logistic regression model that predicts the attractiveness of rural territories for urban youth migration.

## Objective

Estimate the probability that a rural territory is perceived as "attractive" based on dimensions derived from survey data:
- Environmental appeal
- Emotional well-being
- Socioeconomic opportunity
- Infrastructure access
- Behavioral preferences

## Structure

- **data/**: Simulated input dataset.
- **src/**: Main Python script for modeling.
- **figures/**: Placeholder for output visuals (ROC, confusion matrix).

## Setup

```bash
pip install -r requirements.txt
python src/Logistic_Model_Rural_Attractiveness.py
```

## License

MIT License
